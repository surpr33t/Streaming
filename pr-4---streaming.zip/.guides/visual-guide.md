## Visual Inspection Rubric (5 pts)


 - **Style: 5 points**:  You must follow the coding guidelines (use of global variables, indentation, comments, and appropriate variable names) found on the <strong><a href="https://bytes.usc.edu/cs103/assignments/style.html" target="_blank">style guide</a></strong> posted on our website. See below for the rubric by which you will be graded.
    - **Indentation (2|0 pts)** 
        - **2 pts** = Regular indentation used in vast majority of code, 
        - **0 pts** = Multiple LARGE areas of indentation issues
    - **Comments (1|0 pts)** 
        - **1 pts** = Regular comments are used to describe high-level tasks or complex implementations, 
        - **0 pts** = Lacking comments in several places where high level descriptions or rationales would be useful 
    - **Global variables (1|0 pts)** 
        - **1 pts** = Global variables (other than image arrays and masks) were NOT used, 
        - **0 pts** = Global variables were used
    - **Skeleton code (1|0 pts)** 
        - **1 pts** = Did NOT change the code indicated as COMPLETE in the skeleton 
        - **0 pts** = Modified the code given.
)
{Check It!|assessment}(grade-book-313338217)

